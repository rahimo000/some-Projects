#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/internet-module.h"
#include "ns3/applications-module.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("AdovExample");

int main(int argc, char *argv[]) {

  // Log level
  LogComponentEnable("AdovExample", LOG_LEVEL_INFO);

  // Create nodes
  NodeContainer nodes;
  nodes.Create(5);

  // Install wireless devices
  WifiHelper wifi;
  wifi.SetStandard(WIFI_PHY_STANDARD_80211a);
  wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                               "DataMode", StringValue("OfdmRate54Mbps"));
    
  NqosWifiMacHelper mac = NqosWifiMacHelper::Default();
    
  Ssid ssid = Ssid("ns-3-ssid");
    
  for (NodeContainer::Iterator i = nodes.Begin(); i != nodes.End(); ++i) {
    NetDeviceContainer devices = wifi.Install(mac, *i);
    mac.SetType("ns3::AdhocWifiMac");
    mac.SetSsid(ssid);
  }

  // Set up mobility
  MobilityHelper mobility;
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  mobility.Install(nodes);

  // Set up internet stack
  InternetStackHelper internet;
  internet.Install(nodes);

  Ipv4AddressHelper address;
  address.SetBase("10.1.1.0", "255.255.255.0");
  Ipv4InterfaceContainer interfaces = address.Assign(devices);

  // Set up ADOV
  AodvHelper aodv;
  Ipv4GlobalRoutingHelper::PopulateRoutingTables();

  // Create a UDP source application and install it on node 0
  uint16_t port = 5000;
  OnOffHelper onoff("ns3::UdpSocketFactory",
                    InetSocketAddress(interfaces.GetAddress(1), port));
  onoff.SetAttribute("PacketSize", UintegerValue(1024));
  onoff.SetAttribute("DataRate", StringValue("5Mbps"));

  ApplicationContainer sourceApps = onoff.Install(nodes.Get(0));
  sourceApps.Start(Seconds(1.0));
  sourceApps.Stop(Seconds(10.0));

  // Create a UDP sink application and install it on node 4
  PacketSinkHelper sink("ns3::UdpSocketFactory",
                        InetSocketAddress(Ipv4Address::GetAny(), port));
  ApplicationContainer sinkApps = sink.Install(nodes.Get(4));
  sinkApps.Start(Seconds(0.0));
  sinkApps.Stop(Seconds(10.0));

  // Run simulation
  Simulator::Stop(Seconds(10.0));
  Simulator::Run();
  Simulator::Destroy();

  return 0;
}
/*Dans cet exemple, nous avons créé un réseau ad hoc de 5 nœuds, avec des interfaces de réseau sans fil et des adresses IP attribuées à chaque nœud. Nous avons également installé ADOV pour le routage des paquets.

Nous avons ensuite créé une application source UDP sur le nœud 0, qui envoie des paquets à une application de réception UDP sur le nœud 4. Les applications sont configurées pour commencer à transmettre des paquets après 1 seconde*/